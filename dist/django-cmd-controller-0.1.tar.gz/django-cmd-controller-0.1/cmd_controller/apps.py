from django.apps import AppConfig


class CmdControllerConfig(AppConfig):
    name = 'cmd_controller'
